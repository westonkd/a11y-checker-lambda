import checkNode from "tinymce-a11y-checker/lib/modules/node-checker";

window.check = checkNode;
