const issue = require("./issue");

function batchAddIssueParams(issues, eventBody) {
  return {
    RequestItems: {
      "prod-issues": issues.map((iss) => issue(iss, eventBody)),
    },
  };
}

module.exports = batchAddIssueParams;
