const batchAddIssueParams = require("./batchAddIssueParams");
const { BatchWriteItemCommand } = require("@aws-sdk/client-dynamodb");
const { ddbClient } = require("./ddbClient.js");

function writeIssues(issues, eventBody) {
  console.log(JSON.stringify(batchAddIssueParams(issues, eventBody), null, 3))

  ddbClient
    .send(new BatchWriteItemCommand(batchAddIssueParams(issues, eventBody)))
    .then((data) => {
      console.log(data)
    })
    .catch((error) => {
      console.log(error)
    });
}

module.exports = writeIssues;
